# GitHub Profile Viewer - MVP Implementation

## Core Features
1. **Search Interface** - Input field to search GitHub usernames
2. **Profile Display** - Show user avatar, name, bio, location, company
3. **Statistics** - Display followers, following, public repos count
4. **Repository List** - Show user's public repositories with details
5. **Authentication** - Simple login/logout system (mock implementation)
6. **Responsive Design** - Mobile-friendly interface

## Files to Create/Modify
1. `src/pages/Index.tsx` - Main application page with search and profile display
2. `src/components/ProfileCard.tsx` - User profile information component
3. `src/components/RepositoryList.tsx` - Repository listing component
4. `src/components/SearchBar.tsx` - Search input component
5. `src/components/AuthButton.tsx` - Authentication component
6. `src/types/github.ts` - TypeScript interfaces for GitHub API data
7. `src/hooks/useGitHubAPI.ts` - Custom hook for GitHub API calls
8. `index.html` - Update title and meta tags

## Implementation Notes
- Use GitHub REST API v4 for fetching user data
- Implement error handling for invalid usernames
- Add loading states for better UX
- Use localStorage for simple auth state management
- Responsive grid layout for repositories
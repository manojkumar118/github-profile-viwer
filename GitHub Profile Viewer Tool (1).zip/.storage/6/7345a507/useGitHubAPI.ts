import { useState } from 'react';
import { GitHubUser, GitHubRepository } from '../types/github';

export const useGitHubAPI = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchUser = async (username: string): Promise<GitHubUser | null> => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`https://api.github.com/users/${username}`);
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('User not found');
        }
        throw new Error('Failed to fetch user data');
      }
      
      const userData = await response.json();
      return userData;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const fetchUserRepositories = async (username: string): Promise<GitHubRepository[]> => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`https://api.github.com/users/${username}/repos?sort=updated&per_page=12`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch repositories');
      }
      
      const reposData = await response.json();
      return reposData;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      return [];
    } finally {
      setLoading(false);
    }
  };

  return {
    fetchUser,
    fetchUserRepositories,
    loading,
    error
  };
};
import { GitHubUser } from '../types/github';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { MapPin, Building, Link as LinkIcon, Mail, Calendar, Users, GitFork } from 'lucide-react';

interface ProfileCardProps {
  user: GitHubUser;
}

export const ProfileCard = ({ user }: ProfileCardProps) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long'
    });
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <div className="flex flex-col items-center space-y-4">
          <Avatar className="w-24 h-24">
            <AvatarImage src={user.avatar_url} alt={user.login} />
            <AvatarFallback>{user.login.charAt(0).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-2xl font-bold">{user.name || user.login}</h2>
            <p className="text-muted-foreground">@{user.login}</p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {user.bio && (
          <p className="text-center text-muted-foreground">{user.bio}</p>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {user.location && (
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">{user.location}</span>
            </div>
          )}
          
          {user.company && (
            <div className="flex items-center gap-2">
              <Building className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">{user.company}</span>
            </div>
          )}
          
          {user.blog && (
            <div className="flex items-center gap-2">
              <LinkIcon className="w-4 h-4 text-muted-foreground" />
              <a 
                href={user.blog.startsWith('http') ? user.blog : `https://${user.blog}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-blue-600 hover:underline"
              >
                {user.blog}
              </a>
            </div>
          )}
          
          {user.email && (
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">{user.email}</span>
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Calendar className="w-4 h-4" />
          <span>Joined {formatDate(user.created_at)}</span>
        </div>
        
        <div className="flex justify-center gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <GitFork className="w-4 h-4" />
              <span className="font-semibold">{user.public_repos}</span>
            </div>
            <p className="text-xs text-muted-foreground">Repositories</p>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <Users className="w-4 h-4" />
              <span className="font-semibold">{user.followers}</span>
            </div>
            <p className="text-xs text-muted-foreground">Followers</p>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <Users className="w-4 h-4" />
              <span className="font-semibold">{user.following}</span>
            </div>
            <p className="text-xs text-muted-foreground">Following</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
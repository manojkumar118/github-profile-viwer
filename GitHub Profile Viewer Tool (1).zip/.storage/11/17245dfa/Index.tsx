import { useState } from 'react';
import { GitHubUser, GitHubRepository } from '../types/github';
import { useGitHubAPI } from '../hooks/useGitHubAPI';
import { SearchBar } from '../components/SearchBar';
import { ProfileCard } from '../components/ProfileCard';
import { RepositoryList } from '../components/RepositoryList';
import { AuthButton } from '../components/AuthButton';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Skeleton } from '../components/ui/skeleton';
import { Github } from 'lucide-react';

export default function Index() {
  const [user, setUser] = useState<GitHubUser | null>(null);
  const [repositories, setRepositories] = useState<GitHubRepository[]>([]);
  const { fetchUser, fetchUserRepositories, loading, error } = useGitHubAPI();

  const handleSearch = async (username: string) => {
    const userData = await fetchUser(username);
    if (userData) {
      setUser(userData);
      const reposData = await fetchUserRepositories(username);
      setRepositories(reposData);
    } else {
      setUser(null);
      setRepositories([]);
    }
  };

  const ProfileSkeleton = () => (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      <div className="flex flex-col items-center space-y-4">
        <Skeleton className="w-24 h-24 rounded-full" />
        <div className="space-y-2 text-center">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-32" />
        </div>
      </div>
      <div className="space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
      </div>
      <div className="flex justify-center gap-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="text-center space-y-2">
            <Skeleton className="h-6 w-12 mx-auto" />
            <Skeleton className="h-3 w-16" />
          </div>
        ))}
      </div>
    </div>
  );

  const RepositoriesSkeleton = () => (
    <div className="space-y-4">
      <Skeleton className="h-6 w-48 mx-auto" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="space-y-3 p-4 border rounded-lg">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
            <div className="flex justify-between">
              <div className="flex gap-2">
                <Skeleton className="h-4 w-12" />
                <Skeleton className="h-4 w-12" />
              </div>
              <Skeleton className="h-4 w-16" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-center justify-between mb-8 gap-4">
          <div className="flex items-center gap-3">
            <Github className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              GitHub Profile Viewer
            </h1>
          </div>
          <AuthButton />
        </div>

        {/* Search Section */}
        <div className="flex justify-center mb-8">
          <SearchBar onSearch={handleSearch} loading={loading} />
        </div>

        {/* Error Display */}
        {error && (
          <div className="max-w-2xl mx-auto mb-8">
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="space-y-8">
            <ProfileSkeleton />
            <RepositoriesSkeleton />
          </div>
        )}

        {/* Profile and Repositories */}
        {!loading && user && (
          <div className="space-y-8">
            <ProfileCard user={user} />
            <div className="max-w-6xl mx-auto">
              <RepositoryList repositories={repositories} />
            </div>
          </div>
        )}

        {/* Welcome Message */}
        {!loading && !user && !error && (
          <div className="text-center py-16">
            <div className="space-y-4">
              <Github className="w-16 h-16 text-blue-600 mx-auto" />
              <h2 className="text-2xl font-semibold text-gray-800">
                Discover GitHub Profiles
              </h2>
              <p className="text-muted-foreground max-w-md mx-auto">
                Search for any GitHub username to explore their profile, repositories, and contributions.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { User, LogOut } from 'lucide-react';
import { AuthUser } from '../types/github';

export const AuthButton = () => {
  const [authUser, setAuthUser] = useState<AuthUser | null>(null);
  const [username, setUsername] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const savedAuth = localStorage.getItem('githubProfileViewerAuth');
    if (savedAuth) {
      setAuthUser(JSON.parse(savedAuth));
    }
  }, []);

  const handleLogin = () => {
    if (username.trim()) {
      const user: AuthUser = {
        username: username.trim(),
        isAuthenticated: true
      };
      setAuthUser(user);
      localStorage.setItem('githubProfileViewerAuth', JSON.stringify(user));
      setUsername('');
      setIsOpen(false);
    }
  };

  const handleLogout = () => {
    setAuthUser(null);
    localStorage.removeItem('githubProfileViewerAuth');
  };

  if (authUser?.isAuthenticated) {
    return (
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">Welcome, {authUser.username}</span>
        <Button variant="outline" size="sm" onClick={handleLogout}>
          <LogOut className="w-4 h-4 mr-2" />
          Logout
        </Button>
      </div>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <User className="w-4 h-4 mr-2" />
          Login
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Login to GitHub Profile Viewer</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
            />
          </div>
          <Button onClick={handleLogin} className="w-full" disabled={!username.trim()}>
            Login
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
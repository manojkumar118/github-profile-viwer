import { GitHubRepository } from '../types/github';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Star, GitFork, ExternalLink } from 'lucide-react';

interface RepositoryListProps {
  repositories: GitHubRepository[];
}

export const RepositoryList = ({ repositories }: RepositoryListProps) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (repositories.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No public repositories found.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-center">Public Repositories</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {repositories.map((repo) => (
          <Card key={repo.id} className="flex flex-col h-full">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-start justify-between">
                <span className="truncate">{repo.name}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  asChild
                  className="ml-2 flex-shrink-0"
                >
                  <a
                    href={repo.html_url}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </Button>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="flex-1 flex flex-col justify-between">
              <div className="space-y-3">
                {repo.description && (
                  <p className="text-sm text-muted-foreground line-clamp-3">
                    {repo.description}
                  </p>
                )}
                
                <div className="flex flex-wrap gap-2">
                  {repo.language && (
                    <Badge variant="secondary" className="text-xs">
                      {repo.language}
                    </Badge>
                  )}
                  {repo.topics.slice(0, 2).map((topic) => (
                    <Badge key={topic} variant="outline" className="text-xs">
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center justify-between mt-4 pt-3 border-t">
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3" />
                    <span>{repo.stargazers_count}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <GitFork className="w-3 h-3" />
                    <span>{repo.forks_count}</span>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">
                  {formatDate(repo.updated_at)}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};